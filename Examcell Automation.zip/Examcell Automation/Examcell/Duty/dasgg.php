<!-- <?php
include("style.php");
?> -->

<!DOCTYPE html>
<html>
<head>
  <title>Time_Table</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
</head>

<body>
<fieldset>
<form action="Duties_Assigned.php" method="POST">
  
<div class="container-fluid">
  <h1>Duty Assigned:</h1>
  
  <table class="table">
    <div class="col-sm-3">

    <thead>
      <tr>
        <th>Staff Name</th>
        <th>No_of_duties</th>
         <th>Remark</th>
          
      </tr>
    </thead>
    
     <tbody>


    
       </tbody>
        </div>
        </table>
     </form>
</fieldset>
</body>
</html>
                                                                                        
 