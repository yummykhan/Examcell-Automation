<?php
 include("style.php");
?>

<!DOCTYPE html>
<html lang="en">
<head>
  <title>Duty_Adjustment</title>
   <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">

  <style type="text/css">
    .container{
      margin-left: 120px;
      margin-top: 150px;
    }
  </style>
  </head>

<body>    
    <div class="container">
        <div class="row">
            <div class="col-md-12">
                <div class="panel panel-default">
                    <div class="panel-body">
                      <div class="table-responsive-md">
                        <form>
                              <table class="table table-striped table-bordered">
                                <thead>
                                        <tr>
                                          <th>Date</th>
                                          <th>Available_staff</th>
                                          <th>Adjusted_staff_name</th>
                                          <th onclick="color()">Remark</th>
                                        </tr>
                               </thead>
    
     <tbody>
      
        <tr>
           <td><input type="text" name=""></td>
           <td><input type="text" name=""></td>
           <td><input type="text" name=""></td>
           <td><input type="text" name=""></td>
         </tr>
      
        </tbody>
        </table>
   

                       </form>
                    </div>
                </div>
            </div>
        </div>
    </div>
     </div>
</body>


</body>
</html>