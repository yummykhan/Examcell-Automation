<?php
 include("style.php");
  $db = mysqli_connect('localhost','root','','duty');

$result = mysqli_query($db,"select exam,date,subject,session,time from time_table where department='HAS' and sem='I'");

$result2 = mysqli_query($db,"select exam,date,subject,session,time from time_table where department='HAS' and sem='II'");

#COMPUTER

$result3 = mysqli_query($db,"select exam,date,subject,session,time from time_table where department='Computer' and sem='III'");

$result4 = mysqli_query($db,"select exam,date,subject,session,time from time_table where department='Computer' and sem='IV'");

$result5 = mysqli_query($db,"select exam,date,subject,session,time from time_table where department='Computer' and sem='V'");

$result6 = mysqli_query($db,"select exam,date,subject,session,time from time_table where department='Computer' and sem='VI'");

$result7 = mysqli_query($db,"select exam,date,subject,session,time from time_table where department='Computer' and sem='VII'");

$result8 = mysqli_query($db,"select exam,date,subject,session,time from time_table where department='Computer' and sem='VIII'");

#CIVIL

$result9 = mysqli_query($db,"select exam,date,subject,session,time from time_table where department='Civil' and sem='III'");

$result10 = mysqli_query($db,"select exam,date,subject,session,time from time_table where department='Civil' and sem='IV'");

$result11 = mysqli_query($db,"select exam,date,subject,session,time from time_table where department='Civil' and sem='V'");

$result12 = mysqli_query($db,"select exam,date,subject,session,time from time_table where department='Civil' and sem='VI'");

$result13 = mysqli_query($db,"select exam,date,subject,session,time from time_table where department='Civil' and sem='VII'");

$result14 = mysqli_query($db,"select exam,date,subject,session,time from time_table where department='Civil' and sem='VIII'");

#EXTC

$result15 = mysqli_query($db,"select exam,date,subject,session,time from time_table where department='Extc' and sem='III'");

$result16 = mysqli_query($db,"select exam,date,subject,session,time from time_table where department='Extc' and sem='IV'");

$result17 = mysqli_query($db,"select exam,date,subject,session,time from time_table where department='Extc' and sem='V'");

$result18 = mysqli_query($db,"select exam,date,subject,session,time from time_table where department='Extc' and sem='VI'");

$result19 = mysqli_query($db,"select exam,date,subject,session,time from time_table where department='Extc' and sem='VII'");

$result20 = mysqli_query($db,"select exam,date,subject,session,time from time_table where department='Extc' and sem='VIII'");

#ELECTRICAL

$result21 = mysqli_query($db,"select exam,date,subject,session,time from time_table where department='Electrical' and sem='III'");

$result22 = mysqli_query($db,"select exam,date,subject,session,time from time_table where department='Electrical' and sem='IV'");

$result23 = mysqli_query($db,"select exam,date,subject,session,time from time_table where department='Electrical' and sem='V'");

$result24 = mysqli_query($db,"select exam,date,subject,session,time from time_table where department='Electrical' and sem='VI'");

$result25 = mysqli_query($db,"select exam,date,subject,session,time from time_table where department='Electrical' and sem='VII'");

$result26 = mysqli_query($db,"select exam,date,subject,session,time from time_table where department='Electrical' and sem='VIII'");

#MECHANICAL

$result27 = mysqli_query($db,"select exam,date,subject,session,time from time_table where department='Mechanical' and sem='III'");

$result28 = mysqli_query($db,"select exam,date,subject,session,time from time_table where department='Mechanical' and sem='IV'");

$result29 = mysqli_query($db,"select exam,date,subject,session,time from time_table where department='Mechanical' and sem='V'");

$result30 = mysqli_query($db,"select exam,date,subject,session,time from time_table where department='Mechanical' and sem='VI'");

$result31 = mysqli_query($db,"select exam,date,subject,session,time from time_table where department='Mechanical' and sem='VII'");

$result32 = mysqli_query($db,"select exam,date,subject,session,time from time_table where department='Mechanical' and sem='VIII'");

?>

<!DOCTYPE html>
<html>
<head>
  <title>Time_Table</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"></script>
<style type="text/css">
   h3{
      margin-left: 550px;
      color: white;
    }

    h1,h2,th{
      color: white;
    }
    </style>
</head>

<body>
<fieldset>
<form action="" method="POST">
  <h3>Time Table</h3>
<div class="container-fluid">
  
  
  <table class="table">
    <div class="col-sm-3">

    <thead>
     <h1>HAS</h1>
     <h2>SEM I</h2>
      <tr>
        <th>Exam</th>
        <th>Date</th>
        <th>Subject</th>
         <th>Time</th>
        <th>Session</th>
        
          
      </tr>
    </thead>
    
     <tbody>

              <?php while($row= mysqli_fetch_array($result)){?>
        <tr>
           
            <td style="color: white;"><?php echo $row['exam']; ?></td>
            <td style="color: white;"><?php echo $row['date']; ?></td>
            <td style="color: white;"><?php echo $row['subject']; ?></td>
            <td style="color: white;"><?php echo $row['time']; ?></td>
            <td style="color: white;"><?php echo $row['session']; ?></td>
        </tr>
        <?php } ?>

         </tbody>
        </div>

        </table>
       </div>
<div class="container-fluid">
  <h1>HAS</h1>
  <h2>SEM II</h2>
  
  <table class="table">
    <div class="col-sm-3">

    <thead>
    
      <tr>
        <th>Exam</th>
        <th>Date</th>
        <th>Subject</th>
         <th>Time</th>
        <th>Session</th>
        
          
      </tr>
    </thead>
    
     <tbody>
     
              <?php while($row= mysqli_fetch_array($result2)){?>
        <tr>
           
            <td style="color: white;"><?php echo $row['exam']; ?></td>
            <td style="color: white;"><?php echo $row['date']; ?></td>
            <td style="color: white;"><?php echo $row['subject']; ?></td>
            <td style="color: white;"><?php echo $row['time']; ?></td>
            <td style="color: white;"><?php echo $row['session']; ?></td>
        </tr>
        <?php } ?>


       </tbody>
        </div>

        </table>
       </div>
<!-- COMPUTER-->

<div class="container-fluid">
  <h1>Computer</h1>
  <h2>SEM III</h2>
  
  <table class="table">
    <div class="col-sm-3">

    <thead>
    
      <tr>
        <th>Exam</th>
        <th>Date</th>
        <th>Subject</th>
         <th>Time</th>
        <th>Session</th>
        
          
      </tr>
    </thead>
    
     <tbody>
    
              <?php while($row= mysqli_fetch_array($result3)){?>
        <tr>
           
            <td style="color: white;"><?php echo $row['exam']; ?></td>
            <td style="color: white;"><?php echo $row['date']; ?></td>
            <td style="color: white;"><?php echo $row['subject']; ?></td>
            <td style="color: white;"><?php echo $row['time']; ?></td>
            <td style="color: white;"><?php echo $row['session']; ?></td>
        </tr>
        <?php } ?>

   </tbody>
        </div>

        </table>
       </div>


       <div class="container-fluid">
  <h1>Computer</h1>
  <h2>SEM IV</h2>
  
  <table class="table">
    <div class="col-sm-3">

    <thead>
    
      <tr>
        <th>Exam</th>
        <th>Date</th>
        <th>Subject</th>
         <th>Time</th>
        <th>Session</th>
        
          
      </tr>
    </thead>
    
     <tbody>
     
              <?php while($row= mysqli_fetch_array($result4)){?>
        <tr>
           
            <td style="color: white;"><?php echo $row['exam']; ?></td>
            <td style="color: white;"><?php echo $row['date']; ?></td>
            <td style="color: white;"><?php echo $row['subject']; ?></td>
            <td style="color: white;"><?php echo $row['time']; ?></td>
            <td style="color: white;"><?php echo $row['session']; ?></td>
        </tr>
        <?php } ?>



    
       </tbody>
        </div>

        </table>
       </div>


       <div class="container-fluid">
  <h1>Computer</h1>
  <h2>SEM V</h2>
  
  <table class="table">
    <div class="col-sm-3">

    <thead>
    
      <tr>
        <th>Exam</th>
        <th>Date</th>
        <th>Subject</th>
         <th>Time</th>
        <th>Session</th>
        
          
      </tr>
    </thead>
    
     <tbody>
    
              <?php while($row= mysqli_fetch_array($result5)){?>
        <tr>
           
            <td style="color: white;"><?php echo $row['exam']; ?></td>
            <td style="color: white;"><?php echo $row['date']; ?></td>
            <td style="color: white;"><?php echo $row['subject']; ?></td>
            <td style="color: white;"><?php echo $row['time']; ?></td>
            <td style="color: white;"><?php echo $row['session']; ?></td>
        </tr>
        <?php } ?>



    
       </tbody>
        </div>

        </table>
       </div>



<div class="container-fluid">
  <h1>Computer</h1>
  <h2>SEM VI</h2>
  
  <table class="table">
    <div class="col-sm-3">

    <thead>
    
      <tr>
        <th>Exam</th>
        <th>Date</th>
        <th>Subject</th>
         <th>Time</th>
        <th>Session</th>
        
          
      </tr>
    </thead>
    
     <tbody>
     
              <?php while($row= mysqli_fetch_array($result6)){?>
        <tr>
           
            <td style="color: white;"><?php echo $row['exam']; ?></td>
            <td style="color: white;"><?php echo $row['date']; ?></td>
            <td style="color: white;"><?php echo $row['subject']; ?></td>
            <td style="color: white;"><?php echo $row['time']; ?></td>
            <td style="color: white;"><?php echo $row['session']; ?></td>
        </tr>
        <?php } ?>


    
       </tbody>
        </div>

        </table>
       </div>

    
    <div class="container-fluid">
  <h1>Computer</h1>
  <h2>SEM VII</h2>
  
  <table class="table">
    <div class="col-sm-3">

    <thead>
    
      <tr>
        <th>Exam</th>
        <th>Date</th>
        <th>Subject</th>
         <th>Time</th>
        <th>Session</th>
        
          
      </tr>
    </thead>
    
     <tbody>
     
              <?php while($row= mysqli_fetch_array($result7)){?>
        <tr>
           
            <td style="color: white;"><?php echo $row['exam']; ?></td>
            <td style="color: white;"><?php echo $row['date']; ?></td>
            <td style="color: white;"><?php echo $row['subject']; ?></td>
            <td style="color: white;"><?php echo $row['time']; ?></td>
            <td style="color: white;"><?php echo $row['session']; ?></td>
        </tr>
        <?php } ?>



    
       </tbody>
        </div>

        </table>
       </div>


<div class="container-fluid">
  <h1>Computer</h1>
  <h2>SEM VIII</h2>
  
  <table class="table">
    <div class="col-sm-3">

    <thead>
    
      <tr>
        <th>Exam</th>
        <th>Date</th>
        <th>Subject</th>
         <th>Time</th>
        <th>Session</th>
        
          
      </tr>
    </thead>
    
     <tbody>
     
              <?php while($row= mysqli_fetch_array($result8)){?>
        <tr>
           
            <td style="color: white;"><?php echo $row['exam']; ?></td>
            <td style="color: white;"><?php echo $row['date']; ?></td>
            <td style="color: white;"><?php echo $row['subject']; ?></td>
            <td style="color: white;"><?php echo $row['time']; ?></td>
            <td style="color: white;"><?php echo $row['session']; ?></td>
        </tr>
        <?php } ?>
</tbody>
        </div>

        </table>
       </div>

<!-- CIVIL-->

<div class="container-fluid">
  <h1>Civil</h1>
  <h2>SEM III</h2>
  
  <table class="table">
    <div class="col-sm-3">

    <thead>
    
      <tr>
        <th>Exam</th>
        <th>Date</th>
        <th>Subject</th>
         <th>Time</th>
        <th>Session</th>
        
          
      </tr>
    </thead>
    
     <tbody>
     
              <?php while($row= mysqli_fetch_array($result9)){?>
        <tr>
           
            <td style="color: white;"><?php echo $row['exam']; ?></td>
            <td style="color: white;"><?php echo $row['date']; ?></td>
            <td style="color: white;"><?php echo $row['subject']; ?></td>
            <td style="color: white;"><?php echo $row['time']; ?></td>
            <td style="color: white;"><?php echo $row['session']; ?></td>
        </tr>
        <?php } ?>



    
       </tbody>
        </div>

        </table>
       </div>

       <div class="container-fluid">
  <h1>Civil</h1>
  <h2>SEM IV</h2>
  
  <table class="table">
    <div class="col-sm-3">

    <thead>
    
      <tr>
        <th>Exam</th>
        <th>Date</th>
        <th>Subject</th>
         <th>Time</th>
        <th>Session</th>
        
          
      </tr>
    </thead>
    
     <tbody>
     
              <?php while($row= mysqli_fetch_array($result10)){?>
        <tr>
           
            <td style="color: white;"><?php echo $row['exam']; ?></td>
            <td style="color: white;"><?php echo $row['date']; ?></td>
            <td style="color: white;"><?php echo $row['subject']; ?></td>
            <td style="color: white;"><?php echo $row['time']; ?></td>
            <td style="color: white;"><?php echo $row['session']; ?></td>
        </tr>
        <?php } ?>


    
       </tbody>
        </div>

        </table>
       </div>

       <div class="container-fluid">
  <h1>Civil</h1>
  <h2>SEM V</h2>
  
  <table class="table">
    <div class="col-sm-3">

    <thead>
    
      <tr>
        <th>Exam</th>
        <th>Date</th>
        <th>Subject</th>
         <th>Time</th>
        <th>Session</th>
        
          
      </tr>
    </thead>
    
     <tbody>
      
              <?php while($row= mysqli_fetch_array($result11)){?>
        <tr>
           
            <td style="color: white;"><?php echo $row['exam']; ?></td>
            <td style="color: white;"><?php echo $row['date']; ?></td>
            <td style="color: white;"><?php echo $row['subject']; ?></td>
            <td style="color: white;"><?php echo $row['time']; ?></td>
            <td style="color: white;"><?php echo $row['session']; ?></td>
        </tr>
        <?php } ?>


       </tbody>
        </div>

        </table>
       </div>

       <div class="container-fluid">
  <h1>Civil</h1>
  <h2>SEM VI</h2>
  
  <table class="table">
    <div class="col-sm-3">

    <thead>
    
      <tr>
        <th>Exam</th>
        <th>Date</th>
        <th>Subject</th>
         <th>Time</th>
        <th>Session</th>
        
          
      </tr>
    </thead>
    
     <tbody>
     
              <?php while($row= mysqli_fetch_array($result12)){?>
        <tr>
           
            <td style="color: white;"><?php echo $row['exam']; ?></td>
            <td style="color: white;"><?php echo $row['date']; ?></td>
            <td style="color: white;"><?php echo $row['subject']; ?></td>
            <td style="color: white;"><?php echo $row['time']; ?></td>
            <td style="color: white;"><?php echo $row['session']; ?></td>
        </tr>
        <?php } ?>


    
       </tbody>
        </div>

        </table>
       </div>

       <div class="container-fluid">
  <h1>Civil</h1>
  <h2>SEM VII</h2>
  
  <table class="table">
    <div class="col-sm-3">

    <thead>
    
      <tr>
        <th>Exam</th>
        <th>Date</th>
        <th>Subject</th>
         <th>Time</th>
        <th>Session</th>
        
          
      </tr>
    </thead>
    
     <tbody>
      
              <?php while($row= mysqli_fetch_array($result13)){?>
        <tr>
           
            <td style="color: white;"><?php echo $row['exam']; ?></td>
            <td style="color: white;"><?php echo $row['date']; ?></td>
            <td style="color: white;"><?php echo $row['subject']; ?></td>
            <td style="color: white;"><?php echo $row['time']; ?></td>
            <td style="color: white;"><?php echo $row['session']; ?></td>
        </tr>
        <?php } ?>



    
       </tbody>
        </div>

        </table>
       </div>

       <div class="container-fluid">
  <h1>Civil</h1>
  <h2>SEM VIII</h2>
  
  <table class="table">
    <div class="col-sm-3">

    <thead>
    
      <tr>
        <th>Exam</th>
        <th>Date</th>
        <th>Subject</th>
         <th>Time</th>
        <th>Session</th>
        
          
      </tr>
    </thead>
    
     <tbody>
      
              <?php while($row= mysqli_fetch_array($result14)){?>
        <tr>
           
            <td style="color: white;"><?php echo $row['exam']; ?></td>
            <td style="color: white;"><?php echo $row['date']; ?></td>
            <td style="color: white;"><?php echo $row['subject']; ?></td>
            <td style="color: white;"><?php echo $row['time']; ?></td>
            <td style="color: white;"><?php echo $row['session']; ?></td>
        </tr>
        <?php } ?>



    
       </tbody>
        </div>

        </table>
       </div>

   <!-- EXTC-->

    <div class="container-fluid">
  <h1>Extc</h1>
  <h2>SEM III</h2>
  
  <table class="table">
    <div class="col-sm-3">

    <thead>
    
      <tr>
        <th>Exam</th>
        <th>Date</th>
        <th>Subject</th>
         <th>Time</th>
        <th>Session</th>
        
          
      </tr>
    </thead>
    
     <tbody>
      
              <?php while($row= mysqli_fetch_array($result15)){?>
        <tr>
           
            <td style="color: white;"><?php echo $row['exam']; ?></td>
            <td style="color: white;"><?php echo $row['date']; ?></td>
            <td style="color: white;"><?php echo $row['subject']; ?></td>
            <td style="color: white;"><?php echo $row['time']; ?></td>
            <td style="color: white;"><?php echo $row['session']; ?></td>
        </tr>
        <?php } ?>


    
       </tbody>
        </div>

        </table>
       </div>

         <div class="container-fluid">
  <h1>Extc</h1>
  <h2>SEM IV</h2>
  
  <table class="table">
    <div class="col-sm-3">

    <thead>
    
      <tr>
        <th>Exam</th>
        <th>Date</th>
        <th>Subject</th>
         <th>Time</th>
        <th>Session</th>
        
          
      </tr>
    </thead>
    
     <tbody>
     
              <?php while($row= mysqli_fetch_array($result16)){?>
        <tr>
           
            <td style="color: white;"><?php echo $row['exam']; ?></td>
            <td style="color: white;"><?php echo $row['date']; ?></td>
            <td style="color: white;"><?php echo $row['subject']; ?></td>
            <td style="color: white;"><?php echo $row['time']; ?></td>
            <td style="color: white;"><?php echo $row['session']; ?></td>
        </tr>
        <?php } ?>


    
       </tbody>
        </div>

        </table>
       </div>

         <div class="container-fluid">
  <h1>Extc</h1>
  <h2>SEM V</h2>
  
  <table class="table">
    <div class="col-sm-3">

    <thead>
    
      <tr>
        <th>Exam</th>
        <th>Date</th>
        <th>Subject</th>
         <th>Time</th>
        <th>Session</th>
        
          
      </tr>
    </thead>
    
     <tbody>
     
              <?php while($row= mysqli_fetch_array($result17)){?>
        <tr>
           
            <td style="color: white;"><?php echo $row['exam']; ?></td>
            <td style="color: white;"><?php echo $row['date']; ?></td>
            <td style="color: white;"><?php echo $row['subject']; ?></td>
            <td style="color: white;"><?php echo $row['time']; ?></td>
            <td style="color: white;"><?php echo $row['session']; ?></td>
        </tr>
        <?php } ?>


       </tbody>
        </div>

        </table>
       </div>

         <div class="container-fluid">
  <h1>Extc</h1>
  <h2>SEM VI</h2>
  
  <table class="table">
    <div class="col-sm-3">

    <thead>
    
      <tr>
        <th>Exam</th>
        <th>Date</th>
        <th>Subject</th>
         <th>Time</th>
        <th>Session</th>
        
          
      </tr>
    </thead>
    
     <tbody>
      
              <?php while($row= mysqli_fetch_array($result18)){?>
        <tr>
           
            <td style="color: white;"><?php echo $row['exam']; ?></td>
            <td style="color: white;"><?php echo $row['date']; ?></td>
            <td style="color: white;"><?php echo $row['subject']; ?></td>
            <td style="color: white;"><?php echo $row['time']; ?></td>
            <td style="color: white;"><?php echo $row['session']; ?></td>
        </tr>
        <?php } ?>


    
       </tbody>
        </div>

        </table>
       </div>  <div class="container-fluid">
  <h1>Extc</h1>
  <h2>SEM VII</h2>
  
  <table class="table">
    <div class="col-sm-3">

    <thead>
    
      <tr>
        <th>Exam</th>
        <th>Date</th>
        <th>Subject</th>
         <th>Time</th>
        <th>Session</th>
        
          
      </tr>
    </thead>
    
     <tbody>
     
              <?php while($row= mysqli_fetch_array($result19)){?>
        <tr>
           
            <td style="color: white;"><?php echo $row['exam']; ?></td>
            <td style="color: white;"><?php echo $row['date']; ?></td>
            <td style="color: white;"><?php echo $row['subject']; ?></td>
            <td style="color: white;"><?php echo $row['time']; ?></td>
            <td style="color: white;"><?php echo $row['session']; ?></td>
        </tr>
        <?php } ?>


    
       </tbody>
        </div>

        </table>
       </div>

         <div class="container-fluid">
  <h1>Extc</h1>
  <h2>SEM VIII</h2>
  
  <table class="table">
    <div class="col-sm-3">

    <thead>
    
      <tr>
        <th>Exam</th>
        <th>Date</th>
        <th>Subject</th>
         <th>Time</th>
        <th>Session</th>
        
          
      </tr>
    </thead>
    
     <tbody>
    
              <?php while($row= mysqli_fetch_array($result20)){?>
        <tr>
           
            <td style="color: white;"><?php echo $row['exam']; ?></td>
            <td style="color: white;"><?php echo $row['date']; ?></td>
            <td style="color: white;"><?php echo $row['subject']; ?></td>
            <td style="color: white;"><?php echo $row['time']; ?></td>
            <td style="color: white;"><?php echo $row['session']; ?></td>
        </tr>
        <?php } ?>



    
       </tbody>
        </div>

        </table>
       </div>

         <div class="container-fluid">
  <h1>Extc</h1>
  <h2>SEM III</h2>
  
  <table class="table">
    <div class="col-sm-3">

    <thead>
    
      <tr>
        <th>Exam</th>
        <th>Date</th>
        <th>Subject</th>
         <th>Time</th>
        <th>Session</th>
        
          
      </tr>
    </thead>
    
     <tbody>
     
              <?php while($row= mysqli_fetch_array($result)){?>
        <tr>
           
            <td style="color: white;"><?php echo $row['exam']; ?></td>
            <td style="color: white;"><?php echo $row['date']; ?></td>
            <td style="color: white;"><?php echo $row['subject']; ?></td>
            <td style="color: white;"><?php echo $row['time']; ?></td>
            <td style="color: white;"><?php echo $row['session']; ?></td>
        </tr>
        <?php } ?>



    
       </tbody>
        </div>

        </table>
       </div>


  <!-- ELECTRICAL-->

         <div class="container-fluid">
  <h1>Electrical</h1>
  <h2>SEM III</h2>
  
  <table class="table">
    <div class="col-sm-3">

    <thead>
    
      <tr>
        <th>Exam</th>
        <th>Date</th>
        <th>Subject</th>
         <th>Time</th>
        <th>Session</th>
        
          
      </tr>
    </thead>
    
     <tbody>

              <?php while($row= mysqli_fetch_array($result)){?>
        <tr>
           
            <td style="color: white;"><?php echo $row['exam']; ?></td>
            <td style="color: white;"><?php echo $row['date']; ?></td>
            <td style="color: white;"><?php echo $row['subject']; ?></td>
            <td style="color: white;"><?php echo $row['time']; ?></td>
            <td style="color: white;"><?php echo $row['session']; ?></td>
        </tr>
        <?php } ?>


    
       </tbody>
        </div>

        </table>
       </div>



         <div class="container-fluid">
  <h1>Electrical</h1>
  <h2>SEM III</h2>
  
  <table class="table">
    <div class="col-sm-3">

    <thead>
    
      <tr>
        <th>Exam</th>
        <th>Date</th>
        <th>Subject</th>
         <th>Time</th>
        <th>Session</th>
        
          
      </tr>
    </thead>
    
     <tbody>
    
              <?php while($row= mysqli_fetch_array($result)){?>
        <tr>
           
            <td style="color: white;"><?php echo $row['exam']; ?></td>
            <td style="color: white;"><?php echo $row['date']; ?></td>
            <td style="color: white;"><?php echo $row['subject']; ?></td>
            <td style="color: white;"><?php echo $row['time']; ?></td>
            <td style="color: white;"><?php echo $row['session']; ?></td>
        </tr>
        <?php } ?>



    
       </tbody>
        </div>

        </table>
       </div>


         <div class="container-fluid">
  <h1>Electrical</h1>
  <h2>SEM III</h2>
  
  <table class="table">
    <div class="col-sm-3">

    <thead>
    
      <tr>
        <th>Exam</th>
        <th>Date</th>
        <th>Subject</th>
         <th>Time</th>
        <th>Session</th>
        
          
      </tr>
    </thead>
    
     <tbody>
  
              <?php while($row= mysqli_fetch_array($result)){?>
        <tr>
           
            <td style="color: white;"><?php echo $row['exam']; ?></td>
            <td style="color: white;"><?php echo $row['date']; ?></td>
            <td style="color: white;"><?php echo $row['subject']; ?></td>
            <td style="color: white;"><?php echo $row['time']; ?></td>
            <td style="color: white;"><?php echo $row['session']; ?></td>
        </tr>
        <?php } ?>


    
       </tbody>
        </div>

        </table>
       </div>


        <div class="container-fluid">
  <h1>Electrical</h1>
  <h2>SEM IV</h2>
  
  <table class="table">
    <div class="col-sm-3">

    <thead>
    
      <tr>
        <th>Exam</th>
        <th>Date</th>
        <th>Subject</th>
         <th>Time</th>
        <th>Session</th>
        
          
      </tr>
    </thead>
    
     <tbody>
     
              <?php while($row= mysqli_fetch_array($result)){?>
        <tr>
           
            <td style="color: white;"><?php echo $row['exam']; ?></td>
            <td style="color: white;"><?php echo $row['date']; ?></td>
            <td style="color: white;"><?php echo $row['subject']; ?></td>
            <td style="color: white;"><?php echo $row['time']; ?></td>
            <td style="color: white;"><?php echo $row['session']; ?></td>
        </tr>
        <?php } ?>


    
       </tbody>
        </div>

        </table>
       </div>

        <div class="container-fluid">
  <h1>Electrical</h1>
  <h2>SEM V</h2>
  
  <table class="table">
    <div class="col-sm-3">

    <thead>
    
      <tr>
        <th>Exam</th>
        <th>Date</th>
        <th>Subject</th>
         <th>Time</th>
        <th>Session</th>
        
          
      </tr>
    </thead>
    
     <tbody>

              <?php while($row= mysqli_fetch_array($result)){?>
        <tr>
           
            <td style="color: white;"><?php echo $row['exam']; ?></td>
            <td style="color: white;"><?php echo $row['date']; ?></td>
            <td style="color: white;"><?php echo $row['subject']; ?></td>
            <td style="color: white;"><?php echo $row['time']; ?></td>
            <td style="color: white;"><?php echo $row['session']; ?></td>
        </tr>
        <?php } ?>


    
       </tbody>
        </div>

        </table>
       </div>

 <div class="container-fluid">
  <h1>Electrical</h1>
  <h2>SEM VI</h2>
  
  <table class="table">
    <div class="col-sm-3">

    <thead>
    
      <tr>
        <th>Exam</th>
        <th>Date</th>
        <th>Subject</th>
         <th>Time</th>
        <th>Session</th>
        
          
      </tr>
    </thead>
    
     <tbody>
     
              <?php while($row= mysqli_fetch_array($result)){?>
        <tr>
           
            <td style="color: white;"><?php echo $row['exam']; ?></td>
            <td style="color: white;"><?php echo $row['date']; ?></td>
            <td style="color: white;"><?php echo $row['subject']; ?></td>
            <td style="color: white;"><?php echo $row['time']; ?></td>
            <td style="color: white;"><?php echo $row['session']; ?></td>
        </tr>
        <?php } ?>


    
       </tbody>
        </div>

        </table>
       </div>

 <div class="container-fluid">
  <h1>Electrical</h1>
  <h2>SEM VII</h2>
  
  <table class="table">
    <div class="col-sm-3">

    <thead>
    
      <tr>
        <th>Exam</th>
        <th>Date</th>
        <th>Subject</th>
         <th>Time</th>
        <th>Session</th>
        
          
      </tr>
    </thead>
    
     <tbody>
     
              <?php while($row= mysqli_fetch_array($result)){?>
        <tr>
           
            <td style="color: white;"><?php echo $row['exam']; ?></td>
            <td style="color: white;"><?php echo $row['date']; ?></td>
            <td style="color: white;"><?php echo $row['subject']; ?></td>
            <td style="color: white;"><?php echo $row['time']; ?></td>
            <td style="color: white;"><?php echo $row['session']; ?></td>
        </tr>
        <?php } ?>


    
       </tbody>
        </div>

        </table>
       </div>

 <div class="container-fluid">
  <h1>Electrical</h1>
  <h2>SEM VIII</h2>
  
  <table class="table">
    <div class="col-sm-3">

    <thead>
    
      <tr>
        <th>Exam</th>
        <th>Date</th>
        <th>Subject</th>
         <th>Time</th>
        <th>Session</th>
        
          
      </tr>
    </thead>
    
     <tbody>
    
              <?php while($row= mysqli_fetch_array($result)){?>
        <tr>
           
            <td style="color: white;"><?php echo $row['exam']; ?></td>
            <td style="color: white;"><?php echo $row['date']; ?></td>
            <td style="color: white;"><?php echo $row['subject']; ?></td>
            <td style="color: white;"><?php echo $row['time']; ?></td>
            <td style="color: white;"><?php echo $row['session']; ?></td>
        </tr>
        <?php } ?>


       </tbody>
        </div>

        </table>
       </div>

<!--MECHANICAL-->

 <div class="container-fluid">
  <h1>Mechanical</h1>
  <h2>SEM III</h2>
  
  <table class="table">
    <div class="col-sm-3">

    <thead>
    
      <tr>
        <th>Exam</th>
        <th>Date</th>
        <th>Subject</th>
         <th>Time</th>
        <th>Session</th>
        
          
      </tr>
    </thead>
    
     <tbody>
      
              <?php while($row= mysqli_fetch_array($result)){?>
        <tr>
           
            <td style="color: white;"><?php echo $row['exam']; ?></td>
            <td style="color: white;"><?php echo $row['date']; ?></td>
            <td style="color: white;"><?php echo $row['subject']; ?></td>
            <td style="color: white;"><?php echo $row['time']; ?></td>
            <td style="color: white;"><?php echo $row['session']; ?></td>
        </tr>
        <?php } ?>


    
       </tbody>
        </div>

        </table>
       </div>


       <div class="container-fluid">
  <h1>Mechanical</h1>
  <h2>SEM IV</h2>
  
  <table class="table">
    <div class="col-sm-3">

    <thead>
    
      <tr>
        <th>Exam</th>
        <th>Date</th>
        <th>Subject</th>
         <th>Time</th>
        <th>Session</th>
        
          
      </tr>
    </thead>
    
     <tbody>
      
              <?php while($row= mysqli_fetch_array($result)){?>
        <tr>
           
            <td style="color: white;"><?php echo $row['exam']; ?></td>
            <td style="color: white;"><?php echo $row['date']; ?></td>
            <td style="color: white;"><?php echo $row['subject']; ?></td>
            <td style="color: white;"><?php echo $row['time']; ?></td>
            <td style="color: white;"><?php echo $row['session']; ?></td>
        </tr>
        <?php } ?>


       </tbody>
        </div>

        </table>
       </div>


<div class="container-fluid">
  <h1>Mechanical</h1>
  <h2>SEM V</h2>
  
  <table class="table">
    <div class="col-sm-3">

    <thead>
    
      <tr>
        <th>Exam</th>
        <th>Date</th>
        <th>Subject</th>
         <th>Time</th>
        <th>Session</th>
        
          
      </tr>
    </thead>
    
     <tbody>
     
              <?php while($row= mysqli_fetch_array($result)){?>
        <tr>
           
            <td style="color: white;"><?php echo $row['exam']; ?></td>
            <td style="color: white;"><?php echo $row['date']; ?></td>
            <td style="color: white;"><?php echo $row['subject']; ?></td>
            <td style="color: white;"><?php echo $row['time']; ?></td>
            <td style="color: white;"><?php echo $row['session']; ?></td>
        </tr>
        <?php } ?>


    
       </tbody>
        </div>

        </table>
       </div>

       <div class="container-fluid">
  <h1>Mechanical</h1>
  <h2>SEM VI</h2>
  
  <table class="table">
    <div class="col-sm-3">

    <thead>
    
      <tr>
        <th>Exam</th>
        <th>Date</th>
        <th>Subject</th>
         <th>Time</th>
        <th>Session</th>
        
          
      </tr>
    </thead>
    
     <tbody>
    
              <?php while($row= mysqli_fetch_array($result)){?>
        <tr>
           
            <td style="color: white;"><?php echo $row['exam']; ?></td>
            <td style="color: white;"><?php echo $row['date']; ?></td>
            <td style="color: white;"><?php echo $row['subject']; ?></td>
            <td style="color: white;"><?php echo $row['time']; ?></td>
            <td style="color: white;"><?php echo $row['session']; ?></td>
        </tr>
        <?php } ?>


    
       </tbody>
        </div>

        </table>
       </div>

       <div class="container-fluid">
  <h1>Mechanical</h1>
  <h2>SEM VII</h2>
  
  <table class="table">
    <div class="col-sm-3">

    <thead>
    
      <tr>
        <th>Exam</th>
        <th>Date</th>
        <th>Subject</th>
         <th>Time</th>
        <th>Session</th>
        
          
      </tr>
    </thead>
    
     <tbody>
     
              <?php while($row= mysqli_fetch_array($result)){?>
        <tr>
           
            <td style="color: white;"><?php echo $row['exam']; ?></td>
            <td style="color: white;"><?php echo $row['date']; ?></td>
            <td style="color: white;"><?php echo $row['subject']; ?></td>
            <td style="color: white;"><?php echo $row['time']; ?></td>
            <td style="color: white;"><?php echo $row['session']; ?></td>
        </tr>
        <?php } ?>


    
       </tbody>
        </div>

        </table>
       </div>

       <div class="container-fluid">
  <h1>Mechanical</h1>
  <h2>SEM VIII</h2>
  
  <table class="table">
    <div class="col-sm-3">

    <thead>
    
      <tr>
        <th>Exam</th>
        <th>Date</th>
        <th>Subject</th>
         <th>Time</th>
        <th>Session</th>
        
          
      </tr>
    </thead>
    
     <tbody>
    
              <?php while($row= mysqli_fetch_array($result)){?>
        <tr>
           
            <td style="color: white;"><?php echo $row['exam']; ?></td>
            <td style="color: white;"><?php echo $row['date']; ?></td>
            <td style="color: white;"><?php echo $row['subject']; ?></td>
            <td style="color: white;"><?php echo $row['time']; ?></td>
            <td style="color: white;"><?php echo $row['session']; ?></td>
        </tr>
        <?php } ?>


       </tbody>
        </div>

        </table>
       </div>
</form>
</fieldset>


</body>
</html>
                                                                                        
 