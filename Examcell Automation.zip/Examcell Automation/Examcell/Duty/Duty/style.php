 <style type="text/css">

 body{
      background-image: url("3.jpg");
      background-size: cover;
    }
       
        .btn-primary{
    margin-right: 10px;
}

.container{
  margin: 20px 90px;
}
    </style>
