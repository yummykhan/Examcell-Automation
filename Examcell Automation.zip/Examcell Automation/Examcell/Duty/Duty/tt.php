<?php


$conn=mysqli_connect('localhost','root','','duty');
if(!$conn){
  echo '<h1>Error</h1>';
}

    
    $exam = $_POST['exam'];
    $date=$_POST['date'];
    $sem=$_POST['sem'];
    $subject=$_POST['subject'];
    $time=$_POST['time'];
    $session=$_POST['session'];
    $department=$_POST['department']; 
    //  $date2=date_create($date);
    // echo $date= date_format($date2,'d/m/y');
        
      //echo $date;  
 for ($i=0; $i <sizeof($subject) ; $i++) { 
  $sql=" insert into time_table (exam,date,subject,time,session,sem,department) values('$exam[$i]','$date[$i]','$subject[$i]','$time[$i]','$session[$i]','$sem[$i]','$department[$i]') ";
 //echo $date;

 if (mysqli_query($conn, $sql)) 
      {
         header("location: exam.php"); 
     echo "New record created succefully";
      }
  else {
     echo "Error: " . $sql . "<br>" . mysqli_error($conn);
        }
   }
 mysqli_close($conn);

?>
