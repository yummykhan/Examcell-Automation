<?php
	$academic_year=$_POST['academic_year'];

	echo $academic_year;

?>