<!DOCTYPE html>
<html>
<head>
	<title>head</title>
	<link rel="stylesheet" type="text/css" href="css/head.css">
</head>
<body>
	<div class="main_area">

		<div>


			<p>
				<img src="image/logo.jpg" height="100 px" width="100px" class="logo">
				<div style="margin-top: 25px;">
					<div class="anjuman">
						ANJUMAN-I-ISLAM'S,
					</div>
					<br>
					

					<div class="kalsekar">	
						KALSEKAR TECHNICAL CAMPUS,SCHOOL OF ENGINEERING & TECHNOLOGY
						<div class="center">
							CENTER:944,AIISET
						</div>
					</div>

					<br>

					<div class="add">
							NEW PANVEL, DIST-RAIGAD,PIN-410206	
					</div>	
					<br>
					
					<div class="last_line">
						RESULT SHEET FOR 
					</div>
				</div>

			</p>	



		</div>




	</div>

<br>
<hr>
<br>
</body>
</html>