
<!DOCTYPE html>
<html>
<head>
	<title>Gazzete</title>
	<style>
		.container{
			margin-left: 100px;
			margin-right:auto;
			padding-left:15px;
			padding-right:15px;
			font-family: "Comic Sans MS";
		}
		.foot {

			margin-left: 35px;
			font-family: "Comic Sans MS";	
		}

	</style>
</head>
<body>
	<div class="container">
		
		<?php

			include("head.php");
			include("content.php");
		?>

	</div>


	<div class="foot">

		<?php
			include("footer.php");
		?>
	</div>
</body>
</html>