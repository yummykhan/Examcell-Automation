
<!DOCTYPE html>
<html>
<head>
	<title>admin  Gazzete</title>
	<style>
		.container{
			margin-left: 100px;
			margin-right:auto;
			padding-left:15px;
			padding-right:15px;
		}
		.foot {

		}

	</style>
</head>
<body>
	<div class="container">
		
		<?php

			include("head.php");
			include("admin_content.php");
		?>

		<?php
			include("footer.php");
		?>


</div>
</body>
</html>