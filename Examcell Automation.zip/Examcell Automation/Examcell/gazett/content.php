<!DOCTYPE html>
<html>
<head>
	<title>content</title>

	<link rel="stylesheet" type="text/css" href="css/content.css">
</head>
<body>


		<table>
				<tr>
					<th rowspan="3" >Courses</th>
					<th></th>

					<th colspan="3">Subject_code</th>
					<th colspan="3">Subject code</th>
					<th colspan="3">Subject_code</th>
					<th colspan="3">Subject code</th>
					<th colspan="3">Subject code</th>
					<th colspan="3">Subject_code</th>
					<th colspan="3"> Subject code</th>
					<th colspan="3">Subject_code</th>
					<th colspan="3">Subject code</th>

					<th rowspan="4" class="vertical" >Total</th>

					<th rowspan="6" class="vertical"><p>SGPS(GPA)</p></th>

					<th rowspan="6" class="vertical">Result</th>

					<th rowspan="6" class="vertical">CGPI</th>

					<th rowspan="6" class="vertical">RLE</th>
	

					</tr>


				<tr>
					<td rowspan="2"></td>
					<td rowspan="2" colspan="3">Subject_name</td>
					<td rowspan="2" colspan="3">Subject_name</td>
					<td rowspan="2" colspan="3">Subject_name</td>
					<td rowspan="2" colspan="3"> Subject_name</td>
					<td rowspan="2" colspan="3">Subject_name</td>
					<td rowspan="2" colspan="3">Subject_name</td>
					<td rowspan="2" colspan="3">Subject_name</td>
					<td rowspan="2" colspan="3">Subject_name</td>
					<td rowspan="2" colspan="3"> Subject_name</td>
				</tr>

 				<tr>
 					


 				</tr>
				
				<tr>
					<td rowspan="3">Seat No./Name Of Student</td>
					<td></td>
					<td>ESE</td>
					<td>IA</td>
					<td>TOT</td>

					<td>ESE</td>
					<td>IA</td>
					<td>TOT</td>

					<td>ESE</td>
					<td>IA</td>
					<td>TOT</td>

					<td>ESE</td>
					<td>IA</td>
					<td>TOT</td>

					<td>ESE</td>
					<td>IA</td>
					<td>TOT</td>

					<td>ESE</td>
					<td>IA</td>
					<td>TOT</td>

					<td>ESE</td>
					<td>IA</td>
					<td>TOT</td>

					<td>ESE</td>
					<td>IA</td>
					<td>TOT</td>

					<td>ESE</td>
					<td>IA</td>
					<td>TOT</td>

					
				</tr>

				<tr>
					<td>MaxM</td>

					<td></td>
					<td></td>
					<td></td>


					<td></td>
					<td></td>
					<td></td>


					<td></td>
					<td></td>
					<td></td>


					<td></td>
					<td></td>
					<td></td>


					<td></td>
					<td></td>
					<td></td>


					<td></td>
					<td></td>
					<td></td>


					<td></td>
					<td></td>
					<td></td>


					<td></td>
					<td></td>
					<td></td>


					<td></td>
					<td></td>
					<td></td>

					<td></td>
				</tr>


				<tr>
					<td>MinM</td>

					<td></td>
					<td></td>
					<td></td>


					<td></td>
					<td></td>
					<td></td>


					<td></td>
					<td></td>
					<td></td>


					<td></td>
					<td></td>
					<td></td>


					<td></td>
					<td></td>
					<td></td>


					<td></td>
					<td></td>
					<td></td>


					<td></td>
					<td></td>
					<td></td>


					<td></td>
					<td></td>
					<td></td>

					
					<td></td>
					<td></td>
					<td></td>

					<td></td>

				</tr>

				<tr>
					
					<td>Student1_seat</td>
					<td>MarksO</td>


					<td></td>
					<td></td>
					<td></td>


					<td></td>
					<td></td>
					<td></td>


					<td></td>
					<td></td>
					<td></td>


					<td></td>
					<td></td>
					<td></td>


					<td></td>
					<td></td>
					<td></td>


					<td></td>
					<td></td>
					<td></td>


					<td></td>
					<td></td>
					<td></td>


					<td></td>
					<td></td>
					<td></td>

					
					<td></td>
					<td></td>
					<td></td>

					<td></td>

					<td rowspan="4"></td>
					<td rowspan="4"></td>
					<td rowspan="4"></td>
					<td rowspan="4"></td>
				</tr>

				<tr>
					
					<td rowspan="3">Student1_name</td>

					<td>Grade</td>


					<td></td>
					<td></td>
					<td></td>


					<td></td>
					<td></td>
					<td></td>


					<td></td>
					<td></td>
					<td></td>


					<td></td>
					<td></td>
					<td></td>


					<td></td>
					<td></td>
					<td></td>


					<td></td>
					<td></td>
					<td></td>


					<td></td>
					<td></td>
					<td></td>


					<td></td>
					<td></td>
					<td></td>

					
					<td></td>
					<td></td>
					<td></td>

					<td></td>
				</tr>

				<tr>
					
					<td>C</td>


					<td></td>
					<td></td>
					<td></td>


					<td></td>
					<td></td>
					<td></td>


					<td></td>
					<td></td>
					<td></td>


					<td></td>
					<td></td>
					<td></td>


					<td></td>
					<td></td>
					<td></td>


					<td></td>
					<td></td>
					<td></td>


					<td></td>
					<td></td>
					<td></td>


					<td></td>
					<td></td>
					<td></td>

					
					<td></td>
					<td></td>
					<td></td>

					<td></td>
				</tr>

				<tr>
					
					<td>GP*C</td>


					<td></td>
					<td></td>
					<td></td>


					<td></td>
					<td></td>
					<td></td>


					<td></td>
					<td></td>
					<td></td>


					<td></td>
					<td></td>
					<td></td>


					<td></td>
					<td></td>
					<td></td>


					<td></td>
					<td></td>
					<td></td>


					<td></td>
					<td></td>
					<td></td>


					<td></td>
					<td></td>
					<td></td>

					
					<td></td>
					<td></td>
					<td></td>

					<td></td>
				</tr>


		</table>

<br>
<hr>
<br>
</body>
</html>