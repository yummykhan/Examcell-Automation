<!DOCTYPE html>
<html>
<head>
	<title></title>
	<link rel="stylesheet" type="text/css" href="css/foot.css">
</head>
<body >
	<table border="1">

				<tr>
					<td rowspan="2"></td>
					<td rowspan="2" colspan="3">Subject_name</td>
					<td rowspan="2" colspan="3">Subject_name</td>
					<td rowspan="2" colspan="3">Subject_name</td>
					<td rowspan="2" colspan="3"> Subject_name</td>
					<td rowspan="2" colspan="3">Subject_name</td>
					<td rowspan="2" colspan="3">Subject_name</td>
					<td rowspan="2" colspan="3">Subject_name</td>
					<td rowspan="2" colspan="3">Subject_name</td>
					<td rowspan="2" colspan="3"> Subject_name</td>
				</tr>

	</table>
</body>
</html>